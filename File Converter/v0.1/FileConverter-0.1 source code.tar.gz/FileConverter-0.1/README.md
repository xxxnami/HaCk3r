# File Converter

## Description
File Converter is a very simple tool who allows you to convert one or several file(s) from one format to another using the context menu in windows explorer.
This program use [ffmpeg](https://www.ffmpeg.org/) as file conversion tool.

v0.1
You can convert files from formats **Mp3, Ogg, Wav, Flac, Wma** to formats **Mp3, Ogg, Wav, Flac**
﻿// <copyright file="InputPostConversionAction.cs" company="AAllard">License: http://www.gnu.org/licenses/gpl.html GPL version 3.</copyright>

namespace FileConverter
{
    public enum InputPostConversionAction
    {
        None,
        MoveInArchiveFolder,
        Delete,
    }
}

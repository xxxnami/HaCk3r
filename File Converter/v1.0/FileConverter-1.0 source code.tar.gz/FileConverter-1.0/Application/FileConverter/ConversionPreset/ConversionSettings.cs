// <copyright file="ConversionSettings.cs" company="AAllard">License: http://www.gnu.org/licenses/gpl.html GPL version 3.</copyright>

namespace FileConverter
{
    using System.Collections.Generic;

    public class ConversionSettings : Dictionary<string, string>, IConversionSettings
    {
    }
}
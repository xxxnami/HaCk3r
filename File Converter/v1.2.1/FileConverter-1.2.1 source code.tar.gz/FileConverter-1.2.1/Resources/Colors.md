# File Converter Colors

Color       | Code      | Description
------------|-----------|-------------------------------
Blue        | #0171BB   | File Converter main color 
Dark Blue   | #004B82   | File Converter main dark color 
Red         | #FF4100   | Error
Red         | #DF3900   | Title
Grey        | #786C71   | Light text
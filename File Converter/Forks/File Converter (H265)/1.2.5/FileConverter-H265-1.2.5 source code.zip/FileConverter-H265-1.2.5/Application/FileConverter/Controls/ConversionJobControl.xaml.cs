﻿// <copyright file="ConversionJobControl.xaml.cs" company="AAllard">License: http://www.gnu.org/licenses/gpl.html GPL version 3.</copyright>

namespace FileConverter.Controls
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for ConversionJobControl.xaml
    /// </summary>
    public partial class ConversionJobControl : UserControl
    {
        public ConversionJobControl()
        {
            this.InitializeComponent();
        }
    }
}

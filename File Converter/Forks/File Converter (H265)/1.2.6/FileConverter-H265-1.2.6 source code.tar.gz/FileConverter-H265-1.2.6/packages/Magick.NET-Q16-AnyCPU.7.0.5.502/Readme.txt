Please visit https://magick.codeplex.com/documentation for information on how to use Magick.NET.

For a list of changes visit: https://magick.codeplex.com/SourceControl/list/changesets. Be sure to
check the BREAKING CHANGES on this page: https://magick.codeplex.com/SourceControl/latest#Changes.md

Follow me on twitter (@MagickNET, https://twitter.com/MagickNET) to receive information about new
downloads and changes to Magick.NET and ImageMagick.

If you have an uncontrollable urge to give me something for the time and effort I am putting into this
project then please buy me something from my amazon wish list or send me an amazon gift card. You can
find my wishlist here: https://www.amazon.co.uk/registry/wishlist/1C3TE3001VQZE. If you prefer to use
PayPal then contact me on CodePlex to get my information.
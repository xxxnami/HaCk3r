﻿// <copyright file="DiagnosticsWindow.xaml.cs" company="AAllard">License: http://www.gnu.org/licenses/gpl.html GPL version 3.</copyright>

namespace FileConverter.Views
{
    using System.Windows;

    /// <summary>
    /// Interaction logic for DiagnosticsWindow.
    /// </summary>
    public partial class DiagnosticsWindow : Window
    {
        public DiagnosticsWindow()
        {
            this.InitializeComponent();
        }
    }
}

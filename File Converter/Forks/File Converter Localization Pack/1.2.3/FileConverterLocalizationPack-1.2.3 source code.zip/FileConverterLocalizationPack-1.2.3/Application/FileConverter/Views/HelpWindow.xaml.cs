﻿// <copyright file="HelpWindow.xaml.cs" company="AAllard">License: http://www.gnu.org/licenses/gpl.html GPL version 3.</copyright>

namespace FileConverter.Views
{
    using System.Windows;

    public partial class HelpWindow : Window
    {
        public HelpWindow()
        {
            this.InitializeComponent();
        }
    }
}
